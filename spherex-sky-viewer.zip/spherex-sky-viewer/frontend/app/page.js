"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/services/api";
import SearchPanel from "@/components/SearchPanel";
import ObservationList from "@/components/ObservationList";
import ObservationDetails from "@/components/ObservationDetails";
import ScientificImageViewer from "@/components/ScientificImageViewer";
import ExtensionInspector from "@/components/ExtensionInspector";
import FlipbookControls from "@/components/FlipbookControls";

const ACTIVE = ["queued", "downloading", "downloaded", "processing"];

export default function Explore() {
  const [groups, setGroups] = useState([]);
  const [selId, setSelId] = useState(null);
  const [ext, setExt] = useState("IMAGE");
  const [extNames, setExtNames] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [mode, setMode] = useState("single");
  const [det, setDet] = useState(null);
  const [idx, setIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [retrieving, setRetrieving] = useState(false);
  const gRef = useRef(groups);
  gRef.current = groups;

  const allFiles = useMemo(() => groups.flatMap((g) => g.files), [groups]);
  const selFile = allFiles.find((f) => f.file_id === selId) || null;
  const detectors = useMemo(() => [...new Set(allFiles.map((f) => f.detector).filter((d) => d != null))].sort(), [allFiles]);
  const frames = useMemo(() => groups.map((g) => ({ g, file: g.files.find((f) => f.detector === det && f.status === "processed") }))
    .filter((x) => x.file).map((x) => ({ ...x.file, time_iso: x.g.time_iso, t_min: x.g.t_min })), [groups, det]);
  const pending = allFiles.filter((f) => f.detector === det && f.access_url && !["processed", "queued", "downloading", "processing", "downloaded"].includes(f.status)).length;
  const shown = mode === "flipbook" && frames[idx] ? frames[idx] : selFile;

  const merge = useCallback((recs) => {
    const m = Object.fromEntries(recs.filter((r) => r.file_id).map((r) => [r.file_id, r]));
    setGroups((gs) => gs.map((g) => ({ ...g, files: g.files.map((f) => (m[f.file_id] ? { ...f, ...m[f.file_id] } : f)) })));
  }, []);

  // poll processing status of in-flight files
  useEffect(() => {
    const t = setInterval(async () => {
      const ids = gRef.current.flatMap((g) => g.files).filter((f) => ACTIVE.includes(f.status)).map((f) => f.file_id);
      if (!ids.length) return;
      try { merge(await api.status(ids)); } catch (e) { setNotice(`Status polling problem: ${e.message}`); }
    }, 1500);
    return () => clearInterval(t);
  }, [merge]);

  // flipbook playback
  useEffect(() => {
    if (!playing || frames.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % frames.length), 1500 / speed);
    return () => clearInterval(t);
  }, [playing, speed, frames.length]);
  useEffect(() => { if (idx >= frames.length) setIdx(0); }, [frames.length, idx]);

  // deep link from "My Downloads": /?file=<id>
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("file");
    if (!id) return;
    api.file(id).then((f) => { setGroups([{ group_id: f.group_id, time_iso: f.time_iso, t_min: f.t_min, files: [f] }]); setSelId(f.file_id); setDet(f.detector); })
      .catch((e) => setError(e.message));
  }, []);

  async function onSearch(body) {
    setBusy(true); setError(null); setNotice(null); setPlaying(false);
    try {
      const r = await api.search(body);
      setGroups(r.groups); setSelId(null); setExt("IMAGE"); setMode("single"); setIdx(0);
      const d = r.groups[0]?.files[0]?.detector; setDet(d ?? null);
      setNotice(r.message || `${r.file_count} file(s) in ${r.group_count} pointing(s) from ${r.query.collection}. Nothing has been downloaded yet.`);
    } catch (e) { setError(e.message); setGroups([]); } finally { setBusy(false); }
  }

  async function retrieve(f) {
    try { merge([await api.download(f.file_id)]); } catch (e) { setError(e.message); }
  }
  async function retrieveAll() {
    const ids = allFiles.filter((f) => f.detector === det && f.access_url && ["discovered", "failed"].includes(f.status)).map((f) => f.file_id).slice(0, 25);
    if (!ids.length) return;
    if (!window.confirm(`Queue ${ids.length} FITS download(s) (~70 MB each)?`)) return;
    setRetrieving(true);
    try { merge(await api.downloadBatch(ids)); } catch (e) { setError(e.message); } finally { setRetrieving(false); }
  }
  function select(f) {
    setSelId(f.file_id); setExt("IMAGE"); setMode("single"); setPlaying(false); setDet(f.detector ?? det);
  }

  // extension names for the viewer's extension switcher
  useEffect(() => {
    setExtNames([]);
    if (!shown?.has_file) return;
    api.extensions(shown.file_id).then((x) => setExtNames(x.filter((e) => e.previewable).map((e) => e.name))).catch(() => {});
  }, [shown?.file_id, shown?.has_file]);

  return (
    <div className="grid gap-3 lg:grid-cols-[320px_minmax(0,1fr)_340px]">
      <section className="flex min-h-0 flex-col gap-3">
        <SearchPanel onSearch={onSearch} busy={busy} error={error} />
        {notice && <p className="panel p-2 text-xs text-slate-300">{notice}</p>}
        <ObservationList groups={groups} selectedFile={selFile} onSelect={select} />
      </section>
      <section className="flex min-w-0 flex-col gap-3">
        <ScientificImageViewer file={shown} ext={mode === "flipbook" ? "IMAGE" : ext} onExt={setExt} extNames={mode === "flipbook" ? [] : extNames} />
        {groups.length > 0 && det != null && (
          <div>
            <div className="mb-2 flex gap-2 text-xs">
              <button className={`btn ${mode === "single" ? "btn-primary" : ""}`} onClick={() => { setMode("single"); setPlaying(false); }}>Single observation</button>
              <button className={`btn ${mode === "flipbook" ? "btn-primary" : ""}`} onClick={() => setMode("flipbook")}>Flipbook</button>
            </div>
            {mode === "flipbook" && <FlipbookControls {...{ frames, idx, setIdx, playing, setPlaying, speed, setSpeed, detectors, det, setDet, pending, retrieving, onRetrieveAll: retrieveAll }} />}
          </div>)}
      </section>
      <section className="flex min-w-0 flex-col gap-3">
        <ObservationDetails file={shown} onRetrieve={retrieve} />
        <ExtensionInspector file={shown} ext={ext} onSelectExt={(n) => { setMode("single"); setSelId(shown.file_id); setExt(n); }} />
      </section>
    </div>
  );
}
