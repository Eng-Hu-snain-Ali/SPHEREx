import "./globals.css";
import Header from "@/components/Header";

export const metadata = { title: "SPHEREx Sky Viewer", description: "Explore infrared observations from SPHEREx" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <Header />
        <main className="mx-auto max-w-[1700px] p-3 md:p-4">{children}</main>
      </body>
    </html>
  );
}
