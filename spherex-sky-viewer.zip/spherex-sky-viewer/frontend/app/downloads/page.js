import DownloadManager from "@/components/DownloadManager";
export default function Page() { return <DownloadManager />; }
