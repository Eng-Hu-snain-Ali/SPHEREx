const Item = ({ t, children }) => (<section className="mb-4"><h2 className="mb-1 font-semibold text-slate-100">{t}</h2><p className="text-sm text-slate-300">{children}</p></section>);
const A = ({ href, children }) => <a className="text-indigo-300 underline" href={href} target="_blank" rel="noreferrer">{children}</a>;

export default function Guide() {
  return (
    <article className="panel mx-auto max-w-3xl p-5">
      <h1 className="mb-4 text-lg font-semibold">Data Guide</h1>
      <Item t="What is SPHEREx?">SPHEREx is a NASA infrared space telescope that observes the sky in many narrow wavelength bands. Its images are served by NASA/IPAC IRSA. See <A href="https://caltech-ipac.github.io/spherex-archive-documentation/spherex-data-products">IRSA's SPHEREx data products guide</A> for authoritative details.</Item>
      <Item t="RA and Dec">Right ascension and declination are the sky's longitude and latitude. Here both are decimal degrees (RA 0–360, Dec −90 to +90).</Item>
      <Item t="Search radius">Observations whose footprint overlaps a circle of this radius around your position are returned.</Item>
      <Item t="Collections">IRSA exposes SPHEREx spectral images as separate collections per release (DR1, QR3) and survey (wide, deep). The app lists the ones in IRSA's current documentation.</Item>
      <Item t="FITS files and extensions">FITS is the standard astronomy file format. SPHEREx spectral images are multi-extension files (IMAGE, FLAGS, VARIANCE, ZODI, PSF, WCS-WAVE as described by IRSA). This app inspects each file's real extensions rather than assuming any. IMAGE is the main science image.</Item>
      <Item t="FLAGS and VARIANCE">FLAGS marks per-pixel conditions (a bit mask) and VARIANCE holds per-pixel uncertainty. Exact bit meanings and definitions are in the <A href="https://irsa.ipac.caltech.edu/data/SPHEREx/docs/SPHEREx_Expsupp.pdf">SPHEREx Explanatory Supplement</A>.</Item>
      <Item t="MJy/sr">Megajanskys per steradian: a surface-brightness unit (flux per unit solid angle on the sky).</Item>
      <Item t="Why several detector files per pointing?">SPHEREx has multiple detectors, and IRSA's file names carry a detector number (D1–D6). The app groups files that share a planning period and exposure number into one pointing, and lets you choose a detector. Detectors cover different wavelengths and sky areas, so the flipbook plays one detector at a time.</Item>
      <Item t="Previews vs. data">Previews are block-averaged and stretched (asinh) for display only. The original FITS file is stored untouched and can be downloaded.</Item>
    </article>
  );
}
