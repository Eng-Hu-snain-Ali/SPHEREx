module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: { extend: { colors: { space: { 950: "#050812", 900: "#080d1c", 800: "#0d1428", 700: "#162040" } } } },
  plugins: [],
};
