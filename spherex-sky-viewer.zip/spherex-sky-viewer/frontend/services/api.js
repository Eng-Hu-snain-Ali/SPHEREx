// All browser traffic goes to OUR FastAPI backend; the browser never talks to IRSA directly.
export const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function req(path, opts = {}) {
  let res;
  try {
    res = await fetch(BASE + path, { headers: { "Content-Type": "application/json" }, ...opts });
  } catch {
    throw new Error(`Cannot reach the backend at ${BASE}. Is it running?`);
  }
  if (!res.ok) {
    let d = null;
    try { d = (await res.json()).detail; } catch {}
    if (Array.isArray(d)) d = d.map((e) => `${(e.loc || []).slice(1).join(".")}: ${e.msg}`).join("; ");
    throw new Error(d || `Server error (HTTP ${res.status})`);
  }
  return res.json();
}

export const api = {
  health: () => req("/api/health"),
  search: (body) => req("/api/observations/search", { method: "POST", body: JSON.stringify(body) }),
  file: (id) => req(`/api/files/${id}`),
  status: (ids) => req(`/api/files/status?ids=${ids.join(",")}`),
  download: (id) => req(`/api/files/${id}/download`, { method: "POST" }),
  downloadBatch: (ids) => req("/api/files/download-batch", { method: "POST", body: JSON.stringify({ file_ids: ids }) }),
  extensions: (id) => req(`/api/files/${id}/extensions`),
  previewInfo: (id, ext) => req(`/api/files/${id}/extensions/${ext}/preview-info`),
  pixel: (id, ext, px, py) => req(`/api/files/${id}/pixel?ext=${ext}&px=${px}&py=${py}`),
  downloads: () => req("/api/downloads"),
  remove: (id) => req(`/api/downloads/${id}`, { method: "DELETE" }),
  previewUrl: (id, ext = "IMAGE") => `${BASE}/api/files/${id}/extensions/${ext}/preview`,
  fileUrl: (id) => `${BASE}/api/files/${id}/download-file`,
};
