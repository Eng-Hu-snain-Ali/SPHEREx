"use client";
import { useEffect, useState } from "react";
import { api } from "@/services/api";

export default function ExtensionInspector({ file, ext, onSelectExt }) {
  const [exts, setExts] = useState(null);
  const [err, setErr] = useState(null);
  const [hdr, setHdr] = useState(null);
  const ready = file?.has_file;
  useEffect(() => {
    setExts(null); setErr(null); setHdr(null);
    if (!ready) return;
    api.extensions(file.file_id).then(setExts).catch((e) => setErr(e.message));
  }, [file?.file_id, ready]);
  if (!file) return null;
  return (
    <div className="panel p-3 text-xs">
      <h2 className="mb-2 text-sm font-semibold">FITS extensions</h2>
      {!ready && <p className="text-slate-400">Retrieve the FITS file to inspect its extensions.</p>}
      {err && <p className="text-red-300">{err}</p>}
      {exts && (
        <div className="overflow-x-auto"><table className="w-full text-left">
          <thead className="text-slate-400"><tr><th>#</th><th>Name</th><th>Type</th><th>Shape</th><th>dtype</th><th /></tr></thead>
          <tbody>{exts.map((e) => (
            <tr key={e.index} className={`border-t border-white/5 ${e.name === ext ? "bg-indigo-600/10" : ""}`}>
              <td>{e.index}</td><td className="font-medium">{e.name}</td><td>{e.type}</td>
              <td>{e.shape ? e.shape.join("×") : "none"}</td><td className="max-w-[10rem] truncate" title={e.dtype}>{e.dtype || "–"}</td>
              <td className="space-x-1 whitespace-nowrap py-1">
                {e.previewable && <button className="btn !px-1.5 !py-0.5 !text-xs" onClick={() => onSelectExt(e.name)}>View</button>}
                <button className="btn !px-1.5 !py-0.5 !text-xs" onClick={() => setHdr(hdr?.name === e.name ? null : e)}>Header</button>
              </td>
            </tr>))}</tbody>
        </table></div>
      )}
      {hdr && <pre className="mt-2 max-h-56 overflow-auto rounded bg-space-950 p-2">{hdr.header.map(([k, v, c]) => `${k.padEnd(8)} = ${v}${c ? "  / " + c : ""}`).join("\n")}</pre>}
      {exts && <p className="mt-2 text-slate-500">Extensions without 2-D image data (e.g. tables such as WCS-WAVE, if present) are inspected via their header only.</p>}
    </div>
  );
}
