"use client";
import { useState } from "react";
import { Search, RotateCcw, Crosshair, Loader2 } from "lucide-react";

const COLLECTIONS = [
  ["spherex_dr1", "SPHEREx DR1 (wide)"], ["spherex_dr1_deep", "SPHEREx DR1 (deep)"],
  ["spherex_qr3", "SPHEREx QR3 (wide)"], ["spherex_qr3_deep", "SPHEREx QR3 (deep)"],
];
const EXAMPLE = { ra: "133.795129", dec: "-7.245147", radius: "30", unit: "arcsec", collection: "spherex_qr3" }; // WISE 0855, J2000
const BLANK = { ra: "", dec: "", radius: "30", unit: "arcsec", collection: "spherex_qr3" };

export default function SearchPanel({ onSearch, busy, error }) {
  const [f, setF] = useState(EXAMPLE);
  const [err, setErr] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  function submit(e) {
    e.preventDefault();
    const ra = Number(f.ra), dec = Number(f.dec), radius = Number(f.radius);
    if (f.ra.trim() === "" || !Number.isFinite(ra) || ra < 0 || ra > 360) return setErr("RA must be a number between 0 and 360 degrees.");
    if (f.dec.trim() === "" || !Number.isFinite(dec) || dec < -90 || dec > 90) return setErr("Dec must be a number between -90 and +90 degrees.");
    if (!Number.isFinite(radius) || radius <= 0) return setErr("Search radius must be a positive number.");
    setErr(null);
    onSearch({ ra, dec, radius, radius_unit: f.unit, collection: f.collection });
  }

  return (
    <form onSubmit={submit} className="panel space-y-3 p-3">
      <h2 className="text-sm font-semibold text-slate-100">Observation search</h2>
      <div><label className="label">Right ascension (deg, J2000)</label><input className="input" value={f.ra} onChange={set("ra")} inputMode="decimal" placeholder="0 – 360" /></div>
      <div><label className="label">Declination (deg, J2000)</label><input className="input" value={f.dec} onChange={set("dec")} inputMode="decimal" placeholder="-90 – +90" /></div>
      <div className="grid grid-cols-[1fr_auto] gap-2">
        <div><label className="label">Search radius</label><input className="input" value={f.radius} onChange={set("radius")} inputMode="decimal" /></div>
        <div><label className="label">Unit</label>
          <select className="input" value={f.unit} onChange={set("unit")}><option value="arcsec">arcsec</option><option value="arcmin">arcmin</option><option value="deg">deg</option></select></div>
      </div>
      <div><label className="label">Collection / release</label>
        <select className="input" value={f.collection} onChange={set("collection")}>{COLLECTIONS.map(([v, t]) => <option key={v} value={v}>{t}</option>)}</select></div>
      {(err || error) && <p className="rounded border border-red-500/40 bg-red-950/40 p-2 text-xs text-red-200">{err || error}</p>}
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" disabled={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}{busy ? "Searching IRSA…" : "Search"}</button>
        <button type="button" className="btn" onClick={() => { setF(BLANK); setErr(null); }}><RotateCcw className="h-4 w-4" />Clear</button>
        <button type="button" className="btn" onClick={() => setF(EXAMPLE)} title="WISE 0855"><Crosshair className="h-4 w-4" />Example</button>
      </div>
      {busy && <p className="text-xs text-slate-400">Querying IRSA SIA2 through the backend… large regions can take a while.</p>}
    </form>
  );
}
