"use client";
import { Fragment } from "react";
import { Download, FileDown, Loader2 } from "lucide-react";
import StatusBadge from "./StatusBadge";
import { api } from "@/services/api";

const fmt = (v) => (v == null ? "n/a" : typeof v === "number" ? Number(v.toPrecision(10)).toString() : String(v));

export default function ObservationDetails({ file, onRetrieve }) {
  if (!file) return <div className="panel p-3 text-sm text-slate-400">Select an observation file to see its metadata.</div>;
  const busy = ["queued", "downloading", "processing"].includes(file.status);
  const m = file.meta || {};
  const rows = [["Observation ID", file.obs_id], ["Collection", file.collection], ["Detector", file.detector],
    ["t_min (MJD)", file.t_min], ["t_max (MJD)", file.t_max], ["Start (ISO, UTC assumed)", file.time_iso],
    ["RA (deg)", file.ra], ["Dec (deg)", file.dec], ["em_min (m)", file.em_min], ["em_max (m)", file.em_max],
    ["Estimated size", file.est_size]];
  return (
    <div className="panel p-3 text-sm">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <h2 className="font-semibold">Observation details</h2><StatusBadge file={file} />
      </div>
      {file.error && <p className="mb-2 rounded border border-red-500/40 bg-red-950/40 p-2 text-xs text-red-200">{file.error}</p>}
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-xs">
        {rows.map(([k, v]) => <Fragment key={k}><dt className="text-slate-400">{k}</dt><dd className="break-all">{fmt(v)}</dd></Fragment>)}
        <dt className="text-slate-400">FITS URL</dt><dd className="break-all">{file.access_url || "unavailable"}</dd>
      </dl>
      <div className="mt-3 flex flex-wrap gap-2">
        <button className="btn btn-primary" disabled={busy || !file.access_url || file.status === "processed"} onClick={() => onRetrieve(file)}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
          {file.status === "failed" ? "Retry" : file.status === "processed" ? "Retrieved" : "Retrieve FITS"}
        </button>
        {file.has_file && <a className="btn" href={api.fileUrl(file.file_id)}><FileDown className="h-4 w-4" />Original FITS</a>}
      </div>
      <details className="mt-3 text-xs"><summary className="cursor-pointer text-slate-400">All IRSA columns ({Object.keys(m).length})</summary>
        <pre className="mt-1 max-h-48 overflow-auto rounded bg-space-950 p-2">{JSON.stringify(m, null, 1)}</pre></details>
    </div>
  );
}
