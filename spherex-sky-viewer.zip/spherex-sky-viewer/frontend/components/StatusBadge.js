const STYLE = {
  discovered: ["Discovered", "bg-slate-600/40 text-slate-300"],
  queued: ["Queued", "bg-sky-600/30 text-sky-200"],
  downloading: ["Downloading", "bg-sky-600/40 text-sky-200"],
  downloaded: ["Downloaded", "bg-indigo-600/40 text-indigo-200"],
  processing: ["Processing", "bg-violet-600/40 text-violet-200"],
  processed: ["Preview ready", "bg-emerald-600/40 text-emerald-200"],
  failed: ["Failed", "bg-red-600/40 text-red-200"],
};
export default function StatusBadge({ file }) {
  const [t, c] = STYLE[file.status] || STYLE.discovered;
  const pct = file.status === "downloading" && file.total_bytes ? ` ${Math.round((100 * file.progress_bytes) / file.total_bytes)}%` : "";
  return <span className={`rounded px-1.5 py-0.5 text-[11px] ${c}`}>{t}{pct}</span>;
}
