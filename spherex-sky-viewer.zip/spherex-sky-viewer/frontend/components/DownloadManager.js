"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Trash2, FileDown, RefreshCw, Eye } from "lucide-react";
import { api } from "@/services/api";
import StatusBadge from "./StatusBadge";

const mb = (b) => (b ? (b / 1048576).toFixed(1) + " MB" : "n/a");

export default function DownloadManager() {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState(null);
  const load = useCallback(() => api.downloads().then((r) => { setRows(r); setErr(null); }).catch((e) => setErr(e.message)), []);
  useEffect(() => { load(); }, [load]);
  async function del(r) {
    if (!window.confirm(`Delete ${r.filename} and its previews from the server?`)) return;
    try { await api.remove(r.file_id); load(); } catch (e) { setErr(e.message); }
  }
  return (
    <div className="panel p-3">
      <div className="mb-3 flex items-center gap-2"><h1 className="font-semibold">My Downloads</h1>
        <button className="btn ml-auto" onClick={load}><RefreshCw className="h-4 w-4" />Refresh</button></div>
      {err && <p className="mb-2 text-sm text-red-300">{err}</p>}
      {rows && rows.length === 0 && <p className="text-sm text-slate-400">No FITS files stored on the server.</p>}
      {rows?.length > 0 && (
        <div className="overflow-x-auto"><table className="w-full text-left text-xs">
          <thead className="text-slate-400"><tr><th>Observation</th><th>File</th><th>Downloaded</th><th>Size</th><th>Collection</th><th>Status</th><th /></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.file_id} className="border-t border-white/5">
              <td className="py-1.5">{r.obs_id || "n/a"}</td><td className="max-w-[18rem] truncate" title={r.filename}>{r.filename}</td>
              <td>{r.downloaded_at?.replace("T", " ").slice(0, 19) || "n/a"}</td><td>{mb(r.size)}</td><td>{r.collection}</td><td><StatusBadge file={r} /></td>
              <td className="space-x-1 whitespace-nowrap">
                <Link className="btn !px-1.5 !py-0.5 !text-xs" href={`/?file=${r.file_id}`}><Eye className="h-3.5 w-3.5" />Open</Link>
                <a className="btn !px-1.5 !py-0.5 !text-xs" href={api.fileUrl(r.file_id)}><FileDown className="h-3.5 w-3.5" />FITS</a>
                <button className="btn !px-1.5 !py-0.5 !text-xs" onClick={() => del(r)}><Trash2 className="h-3.5 w-3.5" />Delete</button></td>
            </tr>))}</tbody></table></div>)}
      <p className="mt-3 text-xs text-slate-500">Files live in the backend's data/ folder and survive restarts. If a file disappears from disk it is reported as missing and can be downloaded again.</p>
    </div>
  );
}
