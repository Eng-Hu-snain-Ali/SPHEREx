"use client";
import { Play, Pause, SkipBack, SkipForward, DownloadCloud } from "lucide-react";

export default function FlipbookControls({ frames, idx, setIdx, playing, setPlaying, speed, setSpeed, detectors, det, setDet, pending, onRetrieveAll, retrieving }) {
  const n = frames.length, cur = frames[idx];
  return (
    <div className="panel space-y-2 p-3 text-sm">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="font-semibold">Chronological flipbook</h2>
        <label className="ml-auto flex items-center gap-1 text-xs text-slate-400">Detector
          <select className="input !w-auto" value={det ?? ""} onChange={(e) => { setDet(Number(e.target.value)); setIdx(0); setPlaying(false); }}>
            {detectors.map((d) => <option key={d} value={d}>D{d}</option>)}</select></label>
        <button className="btn" disabled={!pending || retrieving} onClick={onRetrieveAll} title="Queue downloads for this detector (max 25)">
          <DownloadCloud className="h-4 w-4" />Retrieve {pending} more</button>
      </div>
      {n === 0 ? <p className="text-xs text-slate-400">No processed previews for this detector yet. Retrieve observations to build the flipbook; only frames with real previews are played.</p> : (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <button className="btn" onClick={() => setIdx((idx - 1 + n) % n)}><SkipBack className="h-4 w-4" /></button>
            <button className="btn btn-primary" onClick={() => setPlaying(!playing)}>{playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}{playing ? "Pause" : "Play"}</button>
            <button className="btn" onClick={() => setIdx((idx + 1) % n)}><SkipForward className="h-4 w-4" /></button>
            <select className="input !w-auto" value={speed} onChange={(e) => setSpeed(Number(e.target.value))}>
              {[0.5, 1, 2, 4].map((s) => <option key={s} value={s}>{s}x</option>)}</select>
            <span className="ml-auto text-xs">Observation {idx + 1} / {n}</span>
          </div>
          <input type="range" min={0} max={n - 1} value={idx} onChange={(e) => { setIdx(Number(e.target.value)); }} className="w-full accent-indigo-400" />
          <div className="text-xs text-slate-300">Date: {cur?.time_iso ? cur.time_iso.slice(0, 19).replace("T", " ") + " (UTC assumed)" : "n/a"} · MJD {cur?.t_min?.toFixed(4) ?? "n/a"}</div>
        </>)}
    </div>
  );
}
