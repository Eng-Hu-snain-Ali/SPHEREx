"use client";
import { useEffect, useRef, useState } from "react";
import { ZoomIn, ZoomOut, Maximize, Scan, RotateCcw, Download, Loader2 } from "lucide-react";
import { api } from "@/services/api";
import StatusBadge from "./StatusBadge";

export default function ScientificImageViewer({ file, ext, onExt, extNames }) {
  const box = useRef(null), drag = useRef(null);
  const [t, setT] = useState({ k: 1, x: 0, y: 0 });
  const [src, setSrc] = useState(null);       // last successfully loaded preview (kept while the next one loads: no blank frames)
  const [loadErr, setLoadErr] = useState(null);
  const [info, setInfo] = useState(null);
  const [probe, setProbe] = useState(null);
  const ready = file?.status === "processed" || (file?.has_file && ext !== "IMAGE");
  const url = file && ready ? api.previewUrl(file.file_id, ext) : null;

  useEffect(() => {
    if (!url) return;
    setLoadErr(null);
    const im = new Image();
    im.onload = () => { setSrc({ url, id: file.file_id, ext }); setProbe(null); };
    im.onerror = () => setLoadErr("Preview could not be loaded (the backend may have failed to render this extension).");
    im.src = url;
    api.previewInfo(file.file_id, ext).then(setInfo).catch(() => setInfo(null));
  }, [url]);

  useEffect(() => { setT({ k: 1, x: 0, y: 0 }); }, [file?.file_id === src?.id ? 0 : file?.file_id, ext]);

  useEffect(() => {  // non-passive wheel zoom
    const el = box.current; if (!el) return;
    const w = (e) => { e.preventDefault(); setT((p) => ({ ...p, k: Math.min(40, Math.max(0.2, p.k * (e.deltaY < 0 ? 1.15 : 1 / 1.15))) })); };
    el.addEventListener("wheel", w, { passive: false }); return () => el.removeEventListener("wheel", w);
  });

  const zoom = (f) => setT((p) => ({ ...p, k: Math.min(40, Math.max(0.2, p.k * f)) }));
  const down = (e) => { drag.current = { sx: e.clientX, sy: e.clientY, ox: t.x, oy: t.y, moved: false }; e.currentTarget.setPointerCapture(e.pointerId); };
  const move = (e) => { const d = drag.current; if (!d) return; const dx = e.clientX - d.sx, dy = e.clientY - d.sy;
    if (Math.abs(dx) + Math.abs(dy) > 3) d.moved = true; setT((p) => ({ ...p, x: d.ox + dx, y: d.oy + dy })); };
  const up = () => { setTimeout(() => (drag.current = null), 0); };
  async function click(e) {
    if (drag.current?.moved || !file) return;
    const im = e.currentTarget, nx = (e.nativeEvent.offsetX / im.clientWidth) * im.naturalWidth, ny = (e.nativeEvent.offsetY / im.clientHeight) * im.naturalHeight;
    try { setProbe(await api.pixel(file.file_id, ext, nx, ny)); } catch (er) { setProbe({ note: er.message }); }
  }

  const shown = src && file && src.id === file.file_id ? src : src;
  return (
    <div className="panel flex min-h-[60vh] flex-col">
      <div className="flex flex-wrap items-center gap-1.5 border-b border-white/10 p-2">
        <button className="btn" onClick={() => zoom(1.4)} title="Zoom in"><ZoomIn className="h-4 w-4" /></button>
        <button className="btn" onClick={() => zoom(1 / 1.4)} title="Zoom out"><ZoomOut className="h-4 w-4" /></button>
        <button className="btn" onClick={() => setT({ k: 1, x: 0, y: 0 })} title="Fit to screen"><Scan className="h-4 w-4" /></button>
        <button className="btn" onClick={() => setT({ k: 1, x: 0, y: 0 })} title="Reset view"><RotateCcw className="h-4 w-4" /></button>
        <button className="btn" onClick={() => box.current?.requestFullscreen?.()} title="Fullscreen"><Maximize className="h-4 w-4" /></button>
        {shown && <a className="btn" href={shown.url} download={`${file?.obs_id || "preview"}_${shown.ext}.png`} title="Download current preview"><Download className="h-4 w-4" /></a>}
        {extNames?.length > 1 && (
          <select className="input !w-auto" value={ext} onChange={(e) => onExt(e.target.value)} title="FITS extension">
            {extNames.map((n) => <option key={n}>{n}</option>)}</select>)}
        <span className="ml-auto text-xs text-slate-400">{Math.round(t.k * 100)}%</span>
      </div>
      <div ref={box} className="relative flex flex-1 touch-none select-none items-center justify-center overflow-hidden bg-black" style={{ minHeight: 360 }}>
        {shown && (
          <img src={shown.url} alt="SPHEREx FITS preview" draggable={false} onPointerDown={down} onPointerMove={move} onPointerUp={up} onClick={click}
            className="max-h-full max-w-full cursor-crosshair [image-rendering:pixelated]"
            style={{ transform: `translate(${t.x}px,${t.y}px) scale(${t.k})`, maxHeight: "75vh" }} />)}
        {!shown && (
          <div className="p-6 text-center text-sm text-slate-400">
            {!file ? "Search for observations and select one." :
             ["queued", "downloading", "processing"].includes(file.status) ? <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /><StatusBadge file={file} /></span> :
             file.status === "failed" ? <span className="text-red-300">Processing failed: {file.error}</span> :
             "No preview yet. Use “Retrieve FITS” in the details panel."}
          </div>)}
        {loadErr && <div className="absolute bottom-2 left-2 right-2 rounded bg-red-950/80 p-2 text-xs text-red-200">{loadErr}</div>}
        {probe && (
          <div className="pointer-events-none absolute left-2 top-2 rounded bg-black/70 p-2 text-xs">
            {probe.x != null && <div>pixel (x,y) = {probe.x}, {probe.y}</div>}
            {probe.value != null && <div>value = {probe.value.toPrecision(6)} {probe.units || ""}</div>}
            {probe.ra != null && <div>RA, Dec = {probe.ra.toFixed(6)}°, {probe.dec.toFixed(6)}°</div>}
            {probe.note && <div className="text-amber-300">{probe.note}</div>}
          </div>)}
      </div>
      {file && (
        <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 border-t border-white/10 p-2 text-xs text-slate-300 md:grid-cols-4">
          <span>ID: {file.obs_id || "n/a"}</span><span>Date: {file.time_iso ? file.time_iso.slice(0, 19).replace("T", " ") : "n/a"}</span>
          <span>RA/Dec: {file.ra != null ? `${file.ra.toFixed(4)}, ${file.dec?.toFixed(4)}` : "n/a"}</span><span>Collection: {file.collection}</span>
          <span>Extension: {shown?.ext || ext}</span><span>Size: {info ? info.full_shape.join("×") : "n/a"}</span>
          <span>Units: {info?.units || "n/a"}</span><span>Detector: {file.detector ?? "n/a"}</span>
          {info && <span className="col-span-2 text-slate-500 md:col-span-4">Display only: ×{info.downsample_factor} block average; {info.stretch}. Range [{info.display_range.map((v) => v.toPrecision(4)).join(", ")}] {info.units || ""}. Original values are preserved in the FITS file.</span>}
        </div>)}
    </div>
  );
}
