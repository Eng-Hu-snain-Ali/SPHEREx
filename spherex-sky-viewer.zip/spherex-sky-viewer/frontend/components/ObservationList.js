"use client";
import StatusBadge from "./StatusBadge";

export default function ObservationList({ groups, selectedFile, onSelect, flipbookIds }) {
  if (!groups.length) return null;
  return (
    <div className="panel flex min-h-0 flex-1 flex-col">
      <div className="border-b border-white/10 px-3 py-2 text-sm font-semibold">
        Pointings ({groups.length}) <span className="font-normal text-slate-400">· chronological</span>
      </div>
      <ul className="max-h-[42vh] overflow-y-auto lg:max-h-none lg:flex-1">
        {groups.map((g, i) => (
          <li key={g.group_id} className="border-b border-white/5 px-3 py-2">
            <div className="flex items-baseline justify-between text-xs">
              <span className="font-medium text-slate-100">#{i + 1} · {g.time_iso ? g.time_iso.replace("T", " ").slice(0, 19) : "time n/a"}</span>
              <span className="text-slate-500">MJD {g.t_min != null ? g.t_min.toFixed(4) : "n/a"}</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {g.files.map((f) => (
                <button key={f.file_id} onClick={() => onSelect(f)}
                  className={`flex items-center gap-1.5 rounded border px-1.5 py-1 text-xs ${selectedFile?.file_id === f.file_id ? "border-indigo-400 bg-indigo-600/20" : "border-white/10 hover:border-white/30"}`}>
                  <span>{f.detector != null ? `D${f.detector}` : "file"}</span>
                  {f.em_min != null && <span className="text-slate-400">{(f.em_min * 1e6).toFixed(2)}–{(f.em_max * 1e6).toFixed(2)}µm</span>}
                  <StatusBadge file={f} />
                </button>
              ))}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
