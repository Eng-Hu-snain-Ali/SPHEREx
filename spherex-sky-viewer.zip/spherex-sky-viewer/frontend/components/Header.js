"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Telescope, Menu } from "lucide-react";
import { api } from "@/services/api";

export default function Header() {
  const [h, setH] = useState({ state: "checking" });
  const [open, setOpen] = useState(false);
  useEffect(() => {
    let live = true;
    const check = () => api.health().then((d) => live && setH({ state: d.irsa?.reachable ? "ok" : "irsa", d }))
      .catch(() => live && setH({ state: "down" }));
    check(); const t = setInterval(check, 30000);
    return () => { live = false; clearInterval(t); };
  }, []);
  const dot = { ok: "bg-emerald-400", irsa: "bg-amber-400", down: "bg-red-500", checking: "bg-slate-500" }[h.state];
  const label = { ok: "Backend + IRSA reachable", irsa: `Backend OK, IRSA unreachable (${h.d?.irsa?.detail || ""})`, down: "Backend unreachable", checking: "Checking…" }[h.state];
  const links = [["/", "Explore"], ["/downloads", "My Downloads"], ["/guide", "Data Guide"]];
  return (
    <header className="border-b border-white/10 bg-space-900">
      <div className="mx-auto flex max-w-[1700px] items-center gap-4 px-4 py-3">
        <Telescope className="h-6 w-6 text-violet-400" />
        <div>
          <div className="font-semibold tracking-wide">SPHEREx Sky Viewer</div>
          <div className="hidden text-xs text-slate-400 sm:block">Explore infrared observations from SPHEREx</div>
        </div>
        <nav className="ml-6 hidden gap-4 text-sm md:flex">
          {links.map(([href, t]) => <Link key={href} href={href} className="text-slate-300 hover:text-white">{t}</Link>)}
        </nav>
        <div className="ml-auto flex items-center gap-2 text-xs text-slate-400" title={label}>
          <span className={`h-2 w-2 rounded-full ${dot}`} /><span className="hidden lg:inline">{label}</span>
        </div>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="menu"><Menu /></button>
      </div>
      {open && <nav className="flex flex-col gap-2 border-t border-white/10 px-4 py-2 text-sm md:hidden">
        {links.map(([href, t]) => <Link key={href} href={href} onClick={() => setOpen(false)}>{t}</Link>)}</nav>}
    </header>
  );
}
