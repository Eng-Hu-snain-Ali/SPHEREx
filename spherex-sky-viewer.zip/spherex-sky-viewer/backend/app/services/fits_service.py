"""Astropy-based FITS inspection and preview rendering. Original files are only ever opened read-only."""
import json, warnings
from pathlib import Path
import numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from ..config import MAX_PREVIEW_PX

BITPIX = {8: "uint8", 16: "int16", 32: "int32", 64: "int64", -32: "float32", -64: "float64"}
STRETCH = "1st-99.5th percentile clip, then asinh(10x)/asinh(10); display transform only"


class FitsError(Exception):
    pass


def _json(v):
    return v if isinstance(v, (str, int, float, bool)) or v is None else str(v)


def _open(path):
    try:
        return fits.open(path, memmap=True)
    except Exception as e:
        raise FitsError(f"Not a readable FITS file: {e}")


def _is_img(h):
    return isinstance(h, (fits.PrimaryHDU, fits.ImageHDU, fits.CompImageHDU))


def inspect(path):
    out = []
    with _open(path) as hdul:
        for i, h in enumerate(hdul):
            img = _is_img(h)
            shape = dtype = None
            try:
                if img:
                    shape = list(h.shape) if h.header.get("NAXIS", 0) > 0 else None
                    dtype = BITPIX.get(h.header.get("BITPIX"))
                elif h.data is not None:
                    shape = [len(h.data)]
                    dtype = "table: " + ", ".join(h.columns.names)
            except Exception:
                pass
            hdr = [[c.keyword, _json(c.value), c.comment] for c in h.header.cards
                   if c.keyword not in ("", "COMMENT", "HISTORY")][:300]
            out.append(dict(index=i, name=h.name or f"HDU{i}", type=type(h).__name__, shape=shape, dtype=dtype,
                            has_image_data=bool(img and shape), previewable=bool(img and shape and len(shape) == 2),
                            units=h.header.get("BUNIT"), header=hdr))
    if not out:
        raise FitsError("FITS file contains no HDUs")
    return out


def _find(hdul, name):
    for h in hdul:
        if (h.name or "").upper() == name.upper():
            return h
    raise FitsError(f"Extension '{name}' is not present in this file (available: {[h.name for h in hdul]})")


def _factor(shape):
    return max(1, int(np.ceil(max(shape) / MAX_PREVIEW_PX)))


def _downsample(a, f, flags=False):
    if f == 1:
        return (a != 0).astype("float32") if flags else a
    h, w = (a.shape[0] // f) * f, (a.shape[1] // f) * f
    a = a[:h, :w]
    if flags:
        return (a != 0).reshape(h // f, f, w // f, f).mean(axis=(1, 3)).astype("float32")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanmean(a.reshape(h // f, f, w // f, f), axis=(1, 3))


def render_preview(path, ext, out_png: Path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    with _open(path) as hdul:
        h = _find(hdul, ext)
        if not _is_img(h) or h.data is None or h.data.ndim != 2:
            raise FitsError(f"Extension '{ext}' is not a 2-D image and cannot be previewed")
        full_shape = list(h.data.shape)
        units = h.header.get("BUNIT")
        flags = ext.upper() == "FLAGS"
        arr = np.asarray(h.data)
        arr = arr if flags else arr.astype("float32")
        f = _factor(arr.shape)
        small = _downsample(arr, f, flags)
    if not flags:
        small = np.where(np.isfinite(small), small, np.nan)
    finite = small[np.isfinite(small)]
    if finite.size == 0:
        raise FitsError(f"Extension '{ext}' contains no finite pixels")
    lo, hi = np.percentile(finite, [1, 99.5])
    if not hi > lo:
        hi = lo + 1.0
    x = np.clip((small - lo) / (hi - lo), 0, 1)
    x = np.arcsinh(10 * x) / np.arcsinh(10)
    cmap = plt.get_cmap("gray" if flags else "magma").with_extremes(bad="#000000")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.imsave(out_png, np.ma.masked_invalid(x), cmap=cmap, vmin=0, vmax=1, origin="lower")
    info = dict(extension=ext.upper(), full_shape=full_shape, preview_shape=list(small.shape), downsample_factor=f,
                units=units, display_range=[float(lo), float(hi)], stretch=STRETCH,
                finite_fraction=float(finite.size / small.size),
                note="Preview is a display transformation (block-averaged, stretched), not calibrated data.")
    out_png.with_suffix(".json").write_text(json.dumps(info))
    return info


def preview_info(png: Path):
    p = png.with_suffix(".json")
    return json.loads(p.read_text()) if p.exists() else None


def probe(path, ext, px, py):
    """Map a click on the preview (px,py from top-left, in preview pixels) to full-res pixel, value and sky coordinates."""
    with _open(path) as hdul:
        h = _find(hdul, ext)
        if not _is_img(h) or h.data is None or h.data.ndim != 2:
            raise FitsError("Not a 2-D image extension")
        H, W = h.data.shape
        f = _factor((H, W))
        hp = H // f
        row = int(np.clip((hp - 1 - py) * f + f // 2, 0, H - 1))
        col = int(np.clip(px * f + f // 2, 0, W - 1))
        v = float(h.data[row, col])
        res = dict(x=col, y=row, value=v if np.isfinite(v) else None, units=h.header.get("BUNIT"),
                   ra=None, dec=None, note=None)
        try:
            w = WCS(h.header, fobj=hdul).celestial
            if w.has_celestial:
                ra, dec = w.pixel_to_world_values(col, row)
                res.update(ra=float(ra), dec=float(dec))
            else:
                res["note"] = "No celestial WCS in this extension's header"
        except Exception as e:
            res["note"] = f"WCS could not be evaluated: {e}"
    return res
