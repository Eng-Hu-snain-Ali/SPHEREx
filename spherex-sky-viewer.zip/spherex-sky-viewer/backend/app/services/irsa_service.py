"""IRSA SIA2 discovery. Only documented parameters are used: COLLECTION, POS, MAXREC (VOTable is the default output)."""
import hashlib, io, math, re
import numpy as np
import requests
from astropy.io.votable import parse_single_table
from astropy.time import Time
from ..config import SIA_URL, MAXREC, USER_AGENT
from ..security import is_allowed_url


class IrsaError(Exception):
    pass


# Grouping rule: IRSA file names look like level2_<planningperiod>_<exposure>_2D<detector>_spx_...fits
# (pattern seen in IRSA's documented example URLs). Files sharing period+exposure are treated as detector
# products of one pointing. If the name does not match, the file becomes its own group.
_NAME = re.compile(r"level2_(?P<pp>[^_/]+_[^_/]+)_(?P<exp>\d{4})_2D(?P<det>\d)_")


def _clean(v):
    if v is None or v is np.ma.masked or np.ma.is_masked(v):
        return None
    if isinstance(v, bytes):
        return v.decode(errors="replace")
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, (np.floating, float)):
        f = float(v)
        return f if math.isfinite(f) else None
    if isinstance(v, np.bool_):
        return bool(v)
    return v if isinstance(v, (str, int, bool)) else str(v)


def _mjd_to_iso(mjd):
    if mjd is None:
        return None
    try:
        return Time(mjd, format="mjd", scale="utc").isot  # UTC assumed; MJD is always shown beside it
    except Exception:
        return None


def parse_votable(content: bytes, collection: str):
    try:
        tbl = parse_single_table(io.BytesIO(content), verify="ignore").to_table()
    except Exception as e:
        raise IrsaError(f"Could not parse IRSA VOTable response ({e}). Start of response: {content[:200]!r}")
    recs = []
    for i, row in enumerate(tbl):
        d = {c: _clean(row[c]) for c in tbl.colnames}  # all columns kept; optional ones may be absent/None
        url = d.get("access_url")
        valid = is_allowed_url(url)
        m = _NAME.search(url or "")
        file_id = hashlib.sha1((url if valid else f"{collection}|{d.get('obs_id')}|{i}").encode()).hexdigest()[:16]
        group = f"{collection}:{m['pp']}_{m['exp']}" if m else f"{collection}:{d.get('obs_id') or file_id}"
        if not valid:
            d["_note"] = "access_url missing or not on an allowed IRSA host; FITS retrieval disabled"
        recs.append(dict(
            file_id=file_id, group_id=group, collection=collection, obs_id=d.get("obs_id"),
            detector=int(m["det"]) if m else None, ra=d.get("s_ra"), dec=d.get("s_dec"),
            t_min=d.get("t_min"), t_max=d.get("t_max"), time_iso=_mjd_to_iso(d.get("t_min")),
            em_min=d.get("em_min"), em_max=d.get("em_max"), access_url=url if valid else None,
            cloud_access=d.get("cloud_access"), est_size=d.get("access_estsize"), meta=d))
    return recs


def search(ra, dec, radius_deg, collection):
    params = {"COLLECTION": collection, "POS": f"circle {ra} {dec} {radius_deg:.7f}", "MAXREC": MAXREC}
    try:
        r = requests.get(SIA_URL, params=params, timeout=(10, 120), headers={"User-Agent": USER_AGENT})
    except requests.RequestException as e:
        raise IrsaError(f"Could not reach IRSA: {e}")
    if r.status_code != 200:
        raise IrsaError(f"IRSA returned HTTP {r.status_code}: {r.text[:300]}")
    return parse_votable(r.content, collection)


def group_records(recs):
    """Group by pointing; order chronologically by the earliest t_min among a group's files (rule documented in README)."""
    groups = {}
    for r in recs:
        groups.setdefault(r["group_id"], []).append(r)
    out = []
    for gid, files in groups.items():
        ts = [f["t_min"] for f in files if f.get("t_min") is not None]
        t = min(ts) if ts else None
        files.sort(key=lambda f: (f.get("detector") is None, f.get("detector") or 0))
        out.append(dict(group_id=gid, t_min=t, time_iso=_mjd_to_iso(t), files=files))
    out.sort(key=lambda g: (g["t_min"] is None, g["t_min"] or 0))
    return out


def ping():
    try:
        r = requests.get(SIA_URL, params={"COLLECTION": "spherex_qr3", "POS": "circle 133.795129 -7.245147 0.0001", "MAXREC": 1},
                         timeout=8, headers={"User-Agent": USER_AGENT})
        return {"reachable": r.status_code == 200, "detail": f"HTTP {r.status_code}"}
    except requests.RequestException as e:
        return {"reachable": False, "detail": str(e)[:200]}
