"""Background download + processing jobs (thread pool; the frontend polls status)."""
import datetime as dt, threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from .. import db
from ..config import FITS_DIR, MAX_WORKERS, MAX_FITS_BYTES
from ..security import safe_stream
from . import fits_service

_pool = ThreadPoolExecutor(MAX_WORKERS)
_lock = threading.Lock()
ACTIVE = {"queued", "downloading", "processing"}


def enqueue(file_id):
    with _lock:
        rec = db.get(file_id)
        if not rec:
            raise KeyError(file_id)
        if not rec["access_url"]:
            raise ValueError("This record has no valid FITS access URL")
        if rec["status"] in ACTIVE or rec["status"] == "processed":
            return rec
        db.update(file_id, status="queued", error=None)
    _pool.submit(_job, file_id)
    return db.get(file_id)


def _job(file_id):
    try:
        rec = db.get(file_id)
        if not (rec["fits_path"] and Path(rec["fits_path"]).exists()):
            _download(rec)
        db.update(file_id, status="processing")
        path = db.get(file_id)["fits_path"]
        fits_service.inspect(path)  # validates the HDU structure
        fits_service.render_preview(path, "IMAGE", db.preview_path(file_id))
        db.update(file_id, status="processed", error=None)
    except Exception as e:
        db.update(file_id, status="failed", error=f"{type(e).__name__}: {e}")


def _download(rec):
    fid = rec["file_id"]
    db.update(fid, status="downloading", progress_bytes=0)
    dest = FITS_DIR / f"{fid}.fits"
    part = dest.with_suffix(".part")
    try:
        with safe_stream(rec["access_url"]) as r:
            if r.status_code != 200:
                raise RuntimeError(f"IRSA returned HTTP {r.status_code} for the FITS URL")
            total = int(r.headers.get("Content-Length") or 0)
            if total > MAX_FITS_BYTES:
                raise RuntimeError(f"File too large ({total} bytes > limit)")
            db.update(fid, total_bytes=total)
            done, last = 0, 0
            with open(part, "wb") as fh:
                for chunk in r.iter_content(1 << 20):
                    fh.write(chunk)
                    done += len(chunk)
                    if done > MAX_FITS_BYTES:
                        raise RuntimeError("Download exceeded size limit")
                    if done - last >= 2 << 20:
                        db.update(fid, progress_bytes=done)
                        last = done
        with open(part, "rb") as fh:
            if fh.read(6) != b"SIMPLE":
                raise RuntimeError("Downloaded file is not a FITS file (missing SIMPLE header)")
        part.replace(dest)  # original kept byte-for-byte
        sz = dest.stat().st_size
        db.update(fid, status="downloaded", fits_path=str(dest), size=sz, progress_bytes=sz,
                  downloaded_at=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"))
    finally:
        part.unlink(missing_ok=True)
