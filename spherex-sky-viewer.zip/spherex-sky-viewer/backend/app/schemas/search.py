from typing import Literal
from pydantic import BaseModel, Field
from ..config import COLLECTIONS


class SearchRequest(BaseModel):
    ra: float = Field(ge=0, le=360, description="Right ascension, decimal degrees (ICRS/J2000)")
    dec: float = Field(ge=-90, le=90, description="Declination, decimal degrees")
    radius: float = Field(gt=0, description="Search radius")
    radius_unit: Literal["arcsec", "arcmin", "deg"] = "arcsec"
    collection: str = "spherex_qr3"

    def radius_deg(self) -> float:
        return self.radius / {"arcsec": 3600.0, "arcmin": 60.0, "deg": 1.0}[self.radius_unit]

    def validate_all(self):
        if self.collection not in COLLECTIONS:
            raise ValueError(f"Unknown collection '{self.collection}'. Valid: {sorted(COLLECTIONS)}")
        if self.radius_deg() > 0.5:
            raise ValueError("Radius must be <= 0.5 degrees (30 arcmin) to keep searches manageable.")
