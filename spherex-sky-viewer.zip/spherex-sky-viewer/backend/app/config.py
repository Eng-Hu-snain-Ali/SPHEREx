"""Central configuration (override with environment variables)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("SPX_DATA_DIR", BASE_DIR / "data"))
FITS_DIR = DATA_DIR / "fits"
PREVIEW_DIR = DATA_DIR / "previews"
DB_PATH = DATA_DIR / "index.sqlite3"
for _d in (FITS_DIR, PREVIEW_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# Source: IRSA SPHEREx Data Access docs (caltech-ipac.github.io/spherex-archive-documentation/spherex-data-access)
SIA_URL = "https://irsa.ipac.caltech.edu/SIA"
COLLECTIONS = {
    "spherex_dr1": "SPHEREx DR1 (Wide Survey spectral images)",
    "spherex_dr1_deep": "SPHEREx DR1 (Deep Survey spectral images)",
    "spherex_qr3": "SPHEREx QR3 (Wide Survey spectral images)",
    "spherex_qr3_deep": "SPHEREx QR3 (Deep Survey spectral images)",
}
# SSRF protection: the server only ever fetches https URLs on these hosts.
ALLOWED_HOSTS = {h.strip() for h in os.getenv("SPX_ALLOWED_HOSTS", "irsa.ipac.caltech.edu").split(",")}
CORS_ORIGINS = os.getenv("SPX_CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",")
MAX_WORKERS = int(os.getenv("SPX_MAX_WORKERS", "2"))
MAXREC = int(os.getenv("SPX_MAXREC", "2000"))
MAX_FITS_BYTES = int(os.getenv("SPX_MAX_FITS_MB", "600")) * 1024 * 1024
MAX_PREVIEW_PX = int(os.getenv("SPX_MAX_PREVIEW_PX", "1024"))
MAX_BATCH = 25
USER_AGENT = "spherex-sky-viewer/0.1"
