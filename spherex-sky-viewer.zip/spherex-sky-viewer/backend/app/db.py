"""SQLite index of discovered / downloaded files. Persistent across restarts (file lives in data/)."""
import json, sqlite3, threading, time
from pathlib import Path
from .config import DB_PATH, PREVIEW_DIR

_lock = threading.RLock()
_conn = None
META = ["group_id", "collection", "obs_id", "detector", "ra", "dec", "t_min", "t_max", "time_iso",
        "em_min", "em_max", "access_url", "cloud_access", "est_size", "meta_json"]
SCHEMA = """CREATE TABLE IF NOT EXISTS files(
 file_id TEXT PRIMARY KEY, group_id TEXT, collection TEXT, obs_id TEXT, detector INTEGER,
 ra REAL, dec REAL, t_min REAL, t_max REAL, time_iso TEXT, em_min REAL, em_max REAL,
 access_url TEXT, cloud_access TEXT, est_size REAL, meta_json TEXT,
 status TEXT DEFAULT 'discovered', error TEXT, progress_bytes INTEGER DEFAULT 0, total_bytes INTEGER DEFAULT 0,
 fits_path TEXT, size INTEGER, downloaded_at TEXT, updated REAL)"""


def conn():
    global _conn
    with _lock:
        if _conn is None:
            Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
            _conn = sqlite3.connect(DB_PATH, check_same_thread=False)
            _conn.row_factory = sqlite3.Row
            _conn.execute(SCHEMA)
            _conn.commit()
        return _conn


def upsert_many(recs):
    with _lock:
        c = conn()
        sets = ",".join(f"{k}=excluded.{k}" for k in META)  # never touches status/progress/path
        for r in recs:
            r = dict(r, meta_json=json.dumps(r.get("meta", {})), updated=time.time())
            cols = ["file_id"] + META + ["updated"]
            c.execute(f"INSERT INTO files({','.join(cols)}) VALUES({','.join('?'*len(cols))}) "
                      f"ON CONFLICT(file_id) DO UPDATE SET {sets}", [r.get(k) for k in cols])
        c.commit()


def update(file_id, **kw):
    kw["updated"] = time.time()
    with _lock:
        c = conn()
        c.execute(f"UPDATE files SET {','.join(k+'=?' for k in kw)} WHERE file_id=?", [*kw.values(), file_id])
        c.commit()


def _row(row):
    return dict(row) if row else None


def get(file_id):
    with _lock:
        rec = _row(conn().execute("SELECT * FROM files WHERE file_id=?", (file_id,)).fetchone())
    return _refresh(rec)


def get_many(ids):
    return [r for r in (get(i) for i in ids) if r]


def downloaded():
    with _lock:
        rows = [_row(r) for r in conn().execute("SELECT * FROM files WHERE fits_path IS NOT NULL ORDER BY downloaded_at DESC")]
    return [r for r in map(_refresh, rows) if r and r["fits_path"]]


def _refresh(rec):
    """File-existence check: never claim a file that is no longer on disk."""
    if rec and rec["fits_path"] and not Path(rec["fits_path"]).exists():
        update(rec["file_id"], fits_path=None, status="discovered", size=None, progress_bytes=0,
               error="Local FITS file is missing; it can be downloaded again.")
        rec.update(fits_path=None, status="discovered", size=None, progress_bytes=0)
    return rec


def recover_interrupted():
    with _lock:
        conn().execute("UPDATE files SET status='failed', error='Interrupted by server restart' "
                       "WHERE status IN ('queued','downloading','processing')")
        conn().commit()


def preview_path(file_id, ext="IMAGE"):
    return PREVIEW_DIR / f"{file_id}__{ext.upper()}.png"


def public(rec):
    """JSON-safe record for the API (no server filesystem paths)."""
    d = {k: v for k, v in rec.items() if k not in ("fits_path", "meta_json")}
    d["meta"] = json.loads(rec.get("meta_json") or "{}")
    d["has_file"] = bool(rec.get("fits_path"))
    d["preview_ready"] = rec.get("status") == "processed" and preview_path(rec["file_id"]).exists()
    return d
