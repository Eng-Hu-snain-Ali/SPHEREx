from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import db
from .config import CORS_ORIGINS
from .api import observations, files, downloads, health


@asynccontextmanager
async def lifespan(app):
    db.recover_interrupted()
    yield


app = FastAPI(title="SPHEREx Sky Viewer API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_methods=["*"], allow_headers=["*"])
for r in (health.router, observations.router, files.router, downloads.router):
    app.include_router(r)
