import threading
from pathlib import Path
from typing import List
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .. import db
from ..config import MAX_BATCH
from ..services import download_service as ds, fits_service
from ..services.fits_service import FitsError

router = APIRouter(prefix="/api/files", tags=["files"])
PROC = threading.Semaphore(2)  # limit concurrent expensive rendering
CACHE = {"Cache-Control": "public, max-age=3600"}


def _need(file_id):
    rec = db.get(file_id)
    if not rec:
        raise HTTPException(404, "Unknown file id (search first)")
    return rec


def _path(rec):
    if not rec["fits_path"]:
        raise HTTPException(409, "FITS file has not been downloaded yet")
    return rec["fits_path"]


def _safe_ext(ext):
    if not (ext.replace("_", "").replace("-", "").isalnum() and len(ext) <= 32):
        raise HTTPException(400, "Invalid extension name")
    return ext


@router.get("/status")
def status(ids: str = Query(..., description="comma-separated file ids")):
    return [db.public(r) for r in db.get_many([i for i in ids.split(",") if i][:200])]


class Batch(BaseModel):
    file_ids: List[str]


@router.post("/download-batch", status_code=202)
def batch(b: Batch):
    if len(b.file_ids) > MAX_BATCH:
        raise HTTPException(422, f"At most {MAX_BATCH} files per batch")
    out = []
    for i in b.file_ids:
        try:
            out.append(db.public(ds.enqueue(i)))
        except (KeyError, ValueError) as e:
            out.append(dict(file_id=i, status="failed", error=str(e)))
    return out


@router.get("/{file_id}")
def one(file_id: str):
    return db.public(_need(file_id))


@router.post("/{file_id}/download", status_code=202)
def download(file_id: str):
    _need(file_id)
    try:
        return db.public(ds.enqueue(file_id))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/{file_id}/extensions")
def extensions(file_id: str):
    try:
        return fits_service.inspect(_path(_need(file_id)))
    except FitsError as e:
        raise HTTPException(422, str(e))


def _preview(file_id, ext):
    rec = _need(file_id)
    path = _path(rec)
    out = db.preview_path(file_id, _safe_ext(ext))
    if not out.exists():
        try:
            with PROC:
                fits_service.render_preview(path, ext, out)
        except FitsError as e:
            raise HTTPException(422, str(e))
    return out


@router.get("/{file_id}/preview")
def preview(file_id: str):
    return FileResponse(_preview(file_id, "IMAGE"), media_type="image/png", headers=CACHE)


@router.get("/{file_id}/extensions/{ext}/preview")
def ext_preview(file_id: str, ext: str):
    return FileResponse(_preview(file_id, ext), media_type="image/png", headers=CACHE)


@router.get("/{file_id}/extensions/{ext}/preview-info")
def ext_info(file_id: str, ext: str):
    return fits_service.preview_info(_preview(file_id, ext))


@router.get("/{file_id}/pixel")
def pixel(file_id: str, ext: str = "IMAGE", px: float = 0, py: float = 0):
    try:
        return fits_service.probe(_path(_need(file_id)), _safe_ext(ext), px, py)
    except FitsError as e:
        raise HTTPException(422, str(e))


@router.get("/{file_id}/download-file")
def download_file(file_id: str):
    rec = _need(file_id)
    p = Path(_path(rec))
    name = (rec["access_url"] or "").rsplit("/", 1)[-1] or p.name
    return FileResponse(p, media_type="application/fits", filename=name)
