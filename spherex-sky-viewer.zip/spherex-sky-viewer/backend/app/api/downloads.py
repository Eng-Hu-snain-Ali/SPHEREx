from pathlib import Path
from fastapi import APIRouter, HTTPException
from .. import db

router = APIRouter(prefix="/api/downloads", tags=["downloads"])


@router.get("")
def list_downloads():
    out = []
    for r in db.downloaded():
        d = db.public(r)
        d["filename"] = (r["access_url"] or "").rsplit("/", 1)[-1]
        out.append(d)
    return out


@router.delete("/{file_id}")
def delete(file_id: str):
    rec = db.get(file_id)
    if not rec or not rec["fits_path"]:
        raise HTTPException(404, "No local file for this id")
    Path(rec["fits_path"]).unlink(missing_ok=True)
    for p in db.PREVIEW_DIR.glob(f"{file_id}__*"):
        p.unlink(missing_ok=True)
    db.update(file_id, fits_path=None, status="discovered", size=None, progress_bytes=0, error=None, downloaded_at=None)
    return {"deleted": file_id}
