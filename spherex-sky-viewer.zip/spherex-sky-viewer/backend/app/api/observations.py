import json
from fastapi import APIRouter, HTTPException
from .. import db
from ..config import COLLECTIONS
from ..schemas.search import SearchRequest
from ..services import irsa_service
from ..services.irsa_service import IrsaError

router = APIRouter(prefix="/api/observations", tags=["observations"])


def _pub_group(g):
    fresh = db.get_many([f["file_id"] for f in g["files"]])
    return dict(group_id=g["group_id"], t_min=g["t_min"], time_iso=g["time_iso"], files=[db.public(r) for r in fresh])


@router.get("/collections")
def collections():
    return COLLECTIONS


@router.post("/search")
def search(req: SearchRequest):
    try:
        req.validate_all()
    except ValueError as e:
        raise HTTPException(422, str(e))
    try:
        recs = irsa_service.search(req.ra, req.dec, req.radius_deg(), req.collection)
    except IrsaError as e:
        raise HTTPException(502, str(e))
    db.upsert_many(recs)
    groups = [_pub_group(g) for g in irsa_service.group_records(recs)]
    return dict(query=req.model_dump(), radius_deg=req.radius_deg(), file_count=len(recs), group_count=len(groups),
                groups=groups,
                message=None if recs else "IRSA returned no matching observations for this position/radius/collection.")


@router.get("/{group_id:path}")
def group(group_id: str):
    with db._lock:
        ids = [r["file_id"] for r in db.conn().execute("SELECT file_id FROM files WHERE group_id=?", (group_id,))]
    if not ids:
        raise HTTPException(404, "Unknown observation group (search first)")
    recs = [dict(r, meta=json.loads(r.get("meta_json") or "{}")) for r in db.get_many(ids)]
    g = irsa_service.group_records(recs)[0]
    return _pub_group(g)
