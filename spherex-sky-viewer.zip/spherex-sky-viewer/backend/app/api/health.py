from fastapi import APIRouter
from ..services import irsa_service

router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health")
def health(check_irsa: bool = True):
    return {"backend": "ok", "irsa": irsa_service.ping() if check_irsa else None}
