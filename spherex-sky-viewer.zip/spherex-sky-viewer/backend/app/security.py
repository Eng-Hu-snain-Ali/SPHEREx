"""URL validation + redirect-safe streaming (SSRF protection)."""
from urllib.parse import urlparse, urljoin
import requests
from .config import ALLOWED_HOSTS, USER_AGENT


def is_allowed_url(url) -> bool:
    if not isinstance(url, str):
        return False
    p = urlparse(url)
    return p.scheme == "https" and p.hostname in ALLOWED_HOSTS and not p.username and not p.password


def safe_stream(url: str, timeout=(10, 60), max_hops=3) -> requests.Response:
    """GET with streaming; every hop (including redirects) must be on the allow-list."""
    for _ in range(max_hops + 1):
        if not is_allowed_url(url):
            raise ValueError(f"URL not allowed (must be https on {sorted(ALLOWED_HOSTS)}): {url}")
        r = requests.get(url, stream=True, timeout=timeout, allow_redirects=False,
                         headers={"User-Agent": USER_AGENT})
        if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
            url = urljoin(url, r.headers.get("Location", ""))
            r.close()
            continue
        return r
    raise ValueError("Too many redirects")
