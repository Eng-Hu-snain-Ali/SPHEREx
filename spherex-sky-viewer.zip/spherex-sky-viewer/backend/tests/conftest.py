import os, tempfile
os.environ["SPX_DATA_DIR"] = tempfile.mkdtemp(prefix="spx_test_")  # isolate from real data
