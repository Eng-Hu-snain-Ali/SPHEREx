"""Offline tests use small TEST-ONLY synthetic fixtures (never used by the app).
Live IRSA tests run only when SPX_LIVE=1 and network access to irsa.ipac.caltech.edu exists."""
import os, numpy as np, pytest
from astropy.io import fits
from fastapi.testclient import TestClient
from app.main import app
from app.security import is_allowed_url
from app.services import fits_service, irsa_service
from app.services.fits_service import FitsError

client = TestClient(app)

VOT = b"""<?xml version="1.0"?><VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"><RESOURCE><TABLE>
<FIELD name="obs_id" datatype="char" arraysize="*"/><FIELD name="access_url" datatype="char" arraysize="*"/>
<FIELD name="t_min" datatype="double"/><FIELD name="s_ra" datatype="double"/><FIELD name="s_dec" datatype="double"/>
<DATA><TABLEDATA>
<TR><TD>a</TD><TD>https://irsa.ipac.caltech.edu/ibe/data/spherex/qr3/level2/2026W21_2A/v/1/level2_2026W21_2A_0002_2D1_spx_v.fits</TD><TD>61000.5</TD><TD>1</TD><TD>2</TD></TR>
<TR><TD>b</TD><TD>https://irsa.ipac.caltech.edu/ibe/data/spherex/qr3/level2/2026W21_2A/v/2/level2_2026W21_2A_0002_2D2_spx_v.fits</TD><TD>61000.6</TD><TD>1</TD><TD>2</TD></TR>
<TR><TD>c</TD><TD>https://irsa.ipac.caltech.edu/ibe/data/spherex/qr3/level2/2026W20_2A/v/1/level2_2026W20_2A_0001_2D1_spx_v.fits</TD><TD>60990.1</TD><TD>1</TD><TD>2</TD></TR>
<TR><TD>d</TD><TD>http://evil.example.com/x.fits</TD><TD>60995</TD><TD>1</TD><TD>2</TD></TR>
</TABLEDATA></DATA></TABLE></RESOURCE></VOTABLE>"""


def make_fits(path, with_image=True):
    hdus = [fits.PrimaryHDU()]
    if with_image:
        d = np.random.default_rng(0).normal(10, 2, (300, 300)).astype("float32")
        d[5, 5] = np.nan; d[6, 6] = np.inf
        h = fits.ImageHDU(d, name="IMAGE"); h.header["BUNIT"] = "MJy/sr"; hdus.append(h)
    hdus.append(fits.ImageHDU(np.zeros((300, 300), "int32"), name="FLAGS"))
    fits.HDUList(hdus).writeto(path, overwrite=True)


def test_search_validation():
    assert client.post("/api/observations/search", json={"ra": 400, "dec": 0, "radius": 30}).status_code == 422
    assert client.post("/api/observations/search", json={"ra": 10, "dec": 95, "radius": 30}).status_code == 422
    assert client.post("/api/observations/search", json={"ra": 10, "dec": 0, "radius": -1}).status_code == 422
    assert client.post("/api/observations/search", json={"ra": 10, "dec": 0, "radius": 30, "collection": "nope"}).status_code == 422
    assert client.post("/api/observations/search", json={"ra": 10, "dec": 0, "radius": 5, "radius_unit": "deg"}).status_code == 422


def test_ssrf_allowlist():
    assert is_allowed_url("https://irsa.ipac.caltech.edu/ibe/data/spherex/x.fits")
    for bad in ["http://irsa.ipac.caltech.edu/x", "https://evil.com/x", "https://irsa.ipac.caltech.edu@evil.com/x",
                "file:///etc/passwd", None, "https://localhost/x"]:
        assert not is_allowed_url(bad)


def test_votable_parse_grouping_sorting():
    recs = irsa_service.parse_votable(VOT, "spherex_qr3")
    assert len(recs) == 4
    assert [r for r in recs if r["obs_id"] == "d"][0]["access_url"] is None  # off-host URL rejected
    groups = irsa_service.group_records(recs)
    ids = [g["group_id"] for g in groups]
    assert ids[0].endswith("2026W20_2A_0001")          # earliest t_min first
    g2 = [g for g in groups if g["group_id"].endswith("0002")][0]
    assert [f["detector"] for f in g2["files"]] == [1, 2]  # detector files grouped, not separate frames
    assert g2["t_min"] == 61000.5


def test_fits_inspect_and_preview(tmp_path):
    p = tmp_path / "t.fits"; make_fits(p)
    names = [e["name"] for e in fits_service.inspect(p)]
    assert "IMAGE" in names and "FLAGS" in names
    out = tmp_path / "prev.png"
    info = fits_service.render_preview(p, "IMAGE", out)
    assert out.exists() and info["units"] == "MJy/sr" and info["finite_fraction"] > 0.99
    fits_service.render_preview(p, "FLAGS", tmp_path / "f.png")
    px = fits_service.probe(p, "IMAGE", 10, 10)
    assert px["value"] is not None and px["ra"] is None and px["note"]  # no WCS -> no invented coordinates


def test_missing_and_corrupt(tmp_path):
    p = tmp_path / "noimg.fits"; make_fits(p, with_image=False)
    with pytest.raises(FitsError):
        fits_service.render_preview(p, "IMAGE", tmp_path / "x.png")
    bad = tmp_path / "bad.fits"; bad.write_bytes(b"not a fits file at all" * 10)
    with pytest.raises(FitsError):
        fits_service.inspect(bad)


def test_health_and_unknown_file():
    assert client.get("/api/health?check_irsa=false").json()["backend"] == "ok"
    assert client.get("/api/files/doesnotexist").status_code == 404
    assert client.post("/api/files/doesnotexist/download").status_code == 404
    assert client.get("/api/downloads").json() == []


@pytest.mark.skipif(os.getenv("SPX_LIVE") != "1", reason="live IRSA test; set SPX_LIVE=1")
@pytest.mark.parametrize("collection", ["spherex_qr3", "spherex_dr1"])
def test_live_search(collection):
    r = client.post("/api/observations/search", json={"ra": 133.795129, "dec": -7.245147, "radius": 30, "collection": collection})
    assert r.status_code == 200, r.text
    print(collection, r.json()["file_count"], "files /", r.json()["group_count"], "groups")
