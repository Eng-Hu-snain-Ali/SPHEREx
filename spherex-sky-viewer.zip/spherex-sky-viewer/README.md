# SPHEREx Sky Viewer

Next.js (JavaScript, Tailwind) + FastAPI app that searches **real** SPHEREx spectral images via IRSA's SIA2 service,
downloads the real FITS files, renders previews from the `IMAGE` extension with Astropy, and plays pointings chronologically.
No sample/simulated data is used anywhere in the app. If IRSA fails or returns nothing, you see the error / "no results".

## Run (Linux/macOS)
```bash
cd backend && python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000        # API docs: http://localhost:8000/docs

# second terminal
cd frontend && cp ../.env.example .env.local     # keep only NEXT_PUBLIC_API_URL
npm install && npm run dev                       # http://localhost:3000
```
## Run (Windows PowerShell)
```powershell
cd backend; py -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

cd frontend; copy ..\.env.example .env.local; npm install; npm run dev
```
## Tests
```bash
cd backend && python -m pytest -q          # offline tests (synthetic fixtures live ONLY in tests/)
SPX_LIVE=1 python -m pytest -q -s          # adds live IRSA searches (spherex_qr3 + spherex_dr1); needs internet
```

## How it works (checked against IRSA's docs dated Nov 12, 2026)
* Endpoint `https://irsa.ipac.caltech.edu/SIA` with `COLLECTION`, `POS=circle <ra> <dec> <radius_deg>`, `MAXREC`; the default VOTable output is parsed with astropy.
* Collections offered: `spherex_dr1`, `spherex_dr1_deep`, `spherex_qr3`, `spherex_qr3_deep` (QR2 is no longer searchable).
* `access_url` is the FITS URL. Only `https` URLs on `irsa.ipac.caltech.edu` are fetched (SSRF allow-list, redirects re-checked). The browser uses opaque file ids, never URLs.
* **Grouping:** IRSA file names follow `level2_<period>_<exposure>_2D<detector>_...fits` (pattern from IRSA's example URLs). Same period+exposure = one *pointing*; detector files are selectable inside it. Non-matching names become their own group.
* **Chronology rule:** a pointing's time = earliest `t_min` among its files (MJD; ISO shown assuming UTC). Missing `t_min` sorts last.
* **Flipbook** plays one detector at a time and only frames whose preview really exists.
* **Preview:** block-average to <=1024 px, 1-99.5 percentile clip, asinh stretch, NaN/inf masked. Display only; the original FITS is kept byte-for-byte in `backend/data/fits`. Clicking the image gives pixel value and RA/Dec (only if the header has a celestial WCS).
* Status flow: discovered, queued, downloading, downloaded, processing, processed (or failed). "Processed" only after Astropy opened the file and the preview rendered.
* Persistence: SQLite index + files in `backend/data/` survive restarts; jobs interrupted by a restart are marked failed.

## Our API (not IRSA's)
`POST /api/observations/search`, `GET /api/observations/{group_id}`, `POST /api/files/{id}/download`, `POST /api/files/download-batch`,
`GET /api/files/status?ids=`, `GET /api/files/{id}/extensions`, `GET /api/files/{id}/extensions/{ext}/preview` (+ `/preview-info`),
`GET /api/files/{id}/pixel`, `GET /api/files/{id}/download-file`, `GET /api/downloads`, `DELETE /api/downloads/{id}`, `GET /api/health`.
Deviation from the suggested routes: file routes use a `file_id` (one per detector file) because a pointing has several files.

## Feature status
Verified in my sandbox: backend start, health, input validation, VOTable parsing/grouping/sorting, SSRF allow-list, FITS inspect/preview/probe,
missing-IMAGE and corrupt-file errors, honest 502 when IRSA is unreachable, frontend production build.
NOT verified (needs a machine with internet): real IRSA results, real ~70 MB FITS download, real SPHEREx HDU layout/WCS, the UI in a browser.
